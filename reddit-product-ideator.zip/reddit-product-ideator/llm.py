
import os, json, time
from typing import Optional
from tenacity import retry, stop_after_attempt, wait_exponential
from openai import OpenAI

OPENAI_MODEL = os.getenv("OPENAI_MODEL","gpt-4o-mini")

_client = None
def _get_client():
    global _client
    if _client is None:
        _client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
    return _client

@retry(stop=stop_after_attempt(4), wait=wait_exponential(min=1, max=20))
def complete(system: str, user: str) -> str:
    client = _get_client()
    resp = client.chat.completions.create(
        model=OPENAI_MODEL,
        messages=[{"role":"system","content":system},{"role":"user","content":user}],
        temperature=0.4,
    )
    return resp.choices[0].message.content

def complete_json(system: str, user: str):
    txt = complete(system, user)
    # best-effort JSON extraction
    import json, re
    s = txt.strip()
    # Try fenced blocks first
    if "```" in s:
        parts = re.findall(r"```(?:json)?\s*(.*?)\s*```", s, flags=re.S)
        if parts:
            s = parts[0]
    return json.loads(s)


import json
from llm import complete_json
from prompts import SYSTEM_COPY, USER_COPY, SYSTEM_EMAIL, USER_EMAIL

def landing_copy(idea: dict):
    return complete_json(SYSTEM_COPY, USER_COPY.format(idea=json.dumps(idea, ensure_ascii=False)))

def email_sequence(idea: dict):
    return complete_json(SYSTEM_EMAIL, USER_EMAIL.format(idea=json.dumps(idea, ensure_ascii=False)))

# Reddit → Weekly Product Ideator

An automated pipeline that:
1) Scrapes top Reddit threads from selected communities (last 7 days)
2) Extracts discussion highlights
3) Summarizes the main problems/pains/solutions
4) Generates weekly digital product ideas
5) Produces lightweight HTML mockups & marketing copy

## Quickstart

```bash
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.template .env  # fill with your keys
python pipeline.py --subreddits "Entrepreneur+Startups+SaaS" --limit 100 --weeks_back 1
```

Artifacts are written to `outputs/<YYYY-MM-DD>/`:
- `raw_posts.jsonl` / `raw_comments.jsonl`
- `highlights.json`
- `summary.md`
- `ideas.json`
- `landing_<idea_id>.html`, `mobile_<idea_id>.html`, `email_<idea_id>.html`

Open the HTML files in a browser to view mockups.

## Config / Env

Create `.env` from the template:

```
REDDIT_CLIENT_ID=...
REDDIT_CLIENT_SECRET=...
REDDIT_USER_AGENT=product-ideator/0.1 by <yourname>
OPENAI_API_KEY=sk-...
OPENAI_MODEL=gpt-4o-mini
```

> You can swap in another provider by replacing the LLM calls in `llm.py`.

## Schedule Weekly (cron)

Example: run every Monday 07:00

```
0 7 * * 1 cd /path/to/reddit-product-ideator && . .venv/bin/activate && python pipeline.py --subreddits "Entrepreneur+Startups+SaaS" --limit 120 --weeks_back 1
```

## GitHub Actions (optional)

A minimal workflow is included in `.github/workflows/weekly.yml`. Add your secrets in repo settings.

## Notes

- Uses Reddit API (PRAW) – create an app at https://www.reddit.com/prefs/apps
- Clusters threads to reduce duplicates; extracts problem statements; generates ideas, feature lists, pricing, ICP and copy.
- Mockups are pure HTML/CSS, intentionally lightweight; use them as wireframes.
- All LLM prompts are in `prompts.py` – tweak freely.


import time, json, datetime as dt
from typing import List, Dict, Any
from reddit_client import get_reddit

def fetch(subreddits: str, limit: int = 100, weeks_back: int = 1) -> Dict[str, Any]:
    """Fetch top posts & comments from last N weeks across subreddits joined by '+'."""
    reddit = get_reddit()
    since = int((dt.datetime.utcnow() - dt.timedelta(weeks=weeks_back)).timestamp())
    subs = reddit.subreddit(subreddits)
    posts = []
    for post in subs.top(time_filter="week", limit=limit):
        if post.created_utc < since:
            continue
        posts.append({
            "id": post.id,
            "title": post.title,
            "selftext": post.selftext or "",
            "score": post.score,
            "num_comments": post.num_comments,
            "subreddit": str(post.subreddit),
            "url": post.url,
            "created_utc": post.created_utc
        })
    # Comments
    comments = []
    for p in posts:
        submission = reddit.submission(id=p["id"])
        submission.comment_sort = "top"
        submission.comments.replace_more(limit=0)
        for c in submission.comments[:50]:
            comments.append({
                "post_id": p["id"],
                "body": c.body,
                "score": getattr(c, "score", 0)
            })
    return {"posts": posts, "comments": comments}

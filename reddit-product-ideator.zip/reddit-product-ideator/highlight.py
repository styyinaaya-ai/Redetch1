
import json, math
from collections import defaultdict, Counter
from typing import Dict, Any, List
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans

def _text(p):
    return " ".join([p.get("title",""), p.get("selftext","")])

def cluster_posts(posts: List[dict], k: int = 8) -> List[List[dict]]:
    texts = [_text(p) for p in posts]
    if not texts:
        return []
    vec = TfidfVectorizer(max_features=5000, stop_words="english")
    X = vec.fit_transform(texts)
    k = min(k, max(1, len(posts)//2)) or 1
    km = KMeans(n_clusters=k, n_init="auto", random_state=42)
    labels = km.fit_predict(X)
    clusters = defaultdict(list)
    for p, lab in zip(posts, labels):
        clusters[int(lab)].append(p)
    return list(clusters.values())

def top_comments_for(post_id: str, comments: List[dict], n: int = 20) -> List[dict]:
    cs = [c for c in comments if c["post_id"] == post_id]
    cs.sort(key=lambda x: x.get("score",0), reverse=True)
    return cs[:n]

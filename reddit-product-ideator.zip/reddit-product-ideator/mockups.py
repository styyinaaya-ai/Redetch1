
from jinja2 import Environment, FileSystemLoader
from pathlib import Path
import os, json

def render_templates(idea: dict, copy: dict, outdir: str, templates_dir: str = "templates"):
    env = Environment(loader=FileSystemLoader(templates_dir))
    # Landing
    landing = env.get_template("landing_page.html").render(idea=idea, copy=copy)
    Path(outdir, f"landing_{idea['id']}.html").write_text(landing, encoding="utf-8")
    # Mobile
    mobile = env.get_template("mobile_app.html").render(idea=idea, copy=copy)
    Path(outdir, f"mobile_{idea['id']}.html").write_text(mobile, encoding="utf-8")
    # Email
    email = env.get_template("email.html").render(idea=idea, copy=copy)
    Path(outdir, f"email_{idea['id']}.html").write_text(email, encoding="utf-8")

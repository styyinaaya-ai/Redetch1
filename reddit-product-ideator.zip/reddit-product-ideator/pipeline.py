
import os, json, argparse, datetime as dt
from pathlib import Path
from dotenv import load_dotenv

from scrape_reddit import fetch
from highlight import cluster_posts
from summarize import build_insights
from ideate import generate_ideas
from copywriter import landing_copy, email_sequence
from mockups import render_templates

def main(args):
    load_dotenv()
    date_str = dt.datetime.utcnow().strftime("%Y-%m-%d")
    outdir = Path("outputs") / date_str
    outdir.mkdir(parents=True, exist_ok=True)

    print("Fetching Reddit...")
    data = fetch(args.subreddits, limit=args.limit, weeks_back=args.weeks_back)
    (outdir / "raw_posts.jsonl").write_text("\n".join(json.dumps(p) for p in data["posts"]), encoding="utf-8")
    (outdir / "raw_comments.jsonl").write_text("\n".join(json.dumps(c) for c in data["comments"]), encoding="utf-8")

    print("Clustering & building insights...")
    clusters = cluster_posts(data["posts"], k=args.clusters)
    print(f"Clusters: {len(clusters)}")
    insights = build_insights(data["posts"], data["comments"])
    (outdir / "highlights.json").write_text(json.dumps({"clusters":clusters}, ensure_ascii=False, default=str), encoding="utf-8")
    (outdir / "summary.md").write_text(insights, encoding="utf-8")

    print("Generating ideas...")
    ideas = generate_ideas(insights)
    (outdir / "ideas.json").write_text(json.dumps(ideas, ensure_ascii=False, indent=2), encoding="utf-8")

    print("Generating copy + mockups...")
    for idea in ideas:
        try:
            copy = landing_copy(idea)
            emails = email_sequence(idea)
        except Exception as e:
            print("Copy generation failed, skipping:", e)
            continue

        # Save copy assets
        (outdir / f"copy_{idea['id']}.json").write_text(json.dumps(copy, ensure_ascii=False, indent=2), encoding="utf-8")
        (outdir / f"emails_{idea['id']}.json").write_text(json.dumps(emails, ensure_ascii=False, indent=2), encoding="utf-8")

        # Render HTML mockups
        render_templates(idea, copy, str(outdir))

    print("Done. See outputs at:", outdir)

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--subreddits", type=str, required=True, help='e.g. "Entrepreneur+Startups+SaaS"')
    ap.add_argument("--limit", type=int, default=120)
    ap.add_argument("--weeks_back", type=int, default=1)
    ap.add_argument("--clusters", type=int, default=8)
    args = ap.parse_args()
    main(args)

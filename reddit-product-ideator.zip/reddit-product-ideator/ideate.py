
import json
from llm import complete_json
from prompts import SYSTEM_IDEATE, USER_IDEATE

def generate_ideas(insights: str):
    ideas = complete_json(SYSTEM_IDEATE, USER_IDEATE.format(insights=insights))
    # ensure list
    if isinstance(ideas, dict):
        ideas = [ideas]
    return ideas[:8]

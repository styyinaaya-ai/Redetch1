
SYSTEM_SUMMARY = """You are an analyst. You distill Reddit discussions into concise, structured insights.
Focus on user pains, jobs-to-be-done, constraints, and evidence from comments.
Return balanced, non-hyped takeaways.
"""

USER_SUMMARY = """Summarize the following Reddit threads (title, selftext, top comments). Produce:

- 6–10 key pain points with concrete quotes (short, anonymized)
- Jobs-to-be-done bullets
- Existing solutions users tried and their shortcomings
- Implicit constraints (budget, time, tools, region)
- Any strong signals of willingness to pay or urgency

Text:
{chunk}
"""

SYSTEM_IDEATE = """You are a seasoned product strategist and copywriter for digital products (SaaS, apps, templates, courses).
Generate practical, low-scope ideas that a solo indie can build in 2–6 weeks.
"""

USER_IDEATE = """From the insights below, propose 8 digital product ideas. For each, return JSON with keys:
id, name, one_liner, problem, solution, key_features (3–6), ICP, pricing, risks, moat, validation_steps, launch_channels, success_metric.

Insights:
{insights}
"""

SYSTEM_COPY = """You are a conversion copywriter. Keep language simple, specific, and benefit-led."""

USER_COPY = """Write landing page copy blocks for the product below.
Return JSON with: hero_headline, hero_sub, cta_label, features (list of {title, benefit}), social_proof (3 short quotes), faq (4 Q&A).
Product JSON:
{idea}
"""

SYSTEM_EMAIL = """You are an email marketer. Compose concise, value-focused copy."""

USER_EMAIL = """Write a short 5-step onboarding email sequence in JSON list form for the product below.
Each item: {subject, preheader, body_md}.
Product JSON:
{idea}
"""

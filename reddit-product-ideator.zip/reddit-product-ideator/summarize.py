
import json, math
from typing import List, Dict
from llm import complete
from prompts import SYSTEM_SUMMARY, USER_SUMMARY
from highlight import top_comments_for

def chunk_threads(posts: List[dict], comments: List[dict], max_chars: int = 12000) -> List[str]:
    # Pack posts+top comments into chunks under max_chars for LLM
    chunks, cur = [], ""
    for p in posts:
        pcs = "\n".join([c["body"] for c in top_comments_for(p["id"], comments, 15)])
        block = f"# {p['title']}\n{p.get('selftext','')}\n\nTop comments:\n{pcs}\n\n---\n"
        if len(cur) + len(block) > max_chars and cur:
            chunks.append(cur)
            cur = block
        else:
            cur += block
    if cur:
        chunks.append(cur)
    return chunks

def build_insights(posts: List[dict], comments: List[dict]) -> str:
    chunks = chunk_threads(posts, comments)
    summaries = []
    for ch in chunks:
        s = complete(SYSTEM_SUMMARY, USER_SUMMARY.format(chunk=ch))
        summaries.append(s.strip())
    return "\n\n".join(summaries)
